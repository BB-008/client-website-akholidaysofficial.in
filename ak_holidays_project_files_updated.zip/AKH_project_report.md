# Domain: https://akholidaysofficial.in (official)

# AK Holidays — Project Report & Code Snippets

**Checked site:** https://akholidaysofficial.in (official domain) (live scan performed)

## 1) Quick Findings from the live site
- Main sections found: Home, About Us, Package (Kerala, Tamilnadu, karnataka), Service, Gallery, Contact.
- Many images present in gallery and service blocks (filenames like IMG_2577.HEIC, whatsapp images).
- Contact details on footer:
  - Phones: +91-8668118166, +91-7418997508
  - Email: akholidaysofficial@gmail.com
  - Address: 331.Balaji Towers Police Station Roundana, Kangeyam - 638 701
- Site copyright 2025 AK Holidays.
- Contact form exists and shows "Thanks for submitting!" confirmation (likely Wix form with dataset).
- No client-side source code exported (Wix-hosted).

## 2) What to include in this repo (recommended files)
- `README.md` (professional project description and features)
- `index.html` (simple GitHub Pages landing page)
- `/assets` (logo, banner, screenshots)
- `/content` (about-us.md, services.md, packages.md, privacy.md, accessibility.md)
- `velo_samples/booking_handler.js` (example Velo backend code)
- `velo_samples/razorpay_webhook_example.js` (example webhook handler)
- `docs/architecture.md` (ERD and architecture notes)
- `LICENSE`

## 3) Sample code snippets (copy into your Wix Velo backend or repo)

### A) Meta tags (add to page head on Gatsby/Next/static site)
```html
<title>AK Holidays — Curated Travel Packages</title>
<meta name="description" content="Explore curated holiday packages across Kerala, Karnataka and beyond. Choose a ready-made itinerary or create your own roadmap." />
<meta name="keywords" content="AK Holidays, travel agency, Kerala tours, Karnataka tours, Tamil Nadu packages, vehicle rentals" />
<link rel="canonical" href="https://akholidaysofficial.in (official domain)/" />
```

### B) Example Wix Velo backend: booking creation + Razorpay order creation
```javascript
// backend/booking.jsw (Wix Velo)
import wixSecretsBackend from 'wix-secrets-backend';
import wixData from 'wix-data';
import {fetch} from 'wix-fetch';

export async function createBookingAndOrder(bookingDetails) {
  // Save provisional booking to DB
  const booking = await wixData.insert('Bookings', {
    name: bookingDetails.name,
    email: bookingDetails.email,
    packageId: bookingDetails.packageId,
    travellers: bookingDetails.travellers,
    amount: bookingDetails.amount, // in INR rupees
    status: 'PENDING',
    createdAt: new Date()
  });

  // Create Razorpay order via Razorpay REST API (server-side)
  const keyId = await wixSecretsBackend.getSecret('RAZORPAY_KEY_ID');
  const keySecret = await wixSecretsBackend.getSecret('RAZORPAY_KEY_SECRET');
  const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
  const orderPayload = {
    amount: Math.round(bookingDetails.amount * 100), // paise
    currency: 'INR',
    receipt: `booking_${booking._id}`,
    payment_capture: 1
  };

  const res = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(orderPayload)
  });

  const order = await res.json();
  // Save order details to booking
  await wixData.update('Bookings', {...booking, razorpayOrderId: order.id});
  return { bookingId: booking._id, order };
}
```

### C) Client-side Razorpay Checkout integration (in page code)
```javascript
// page code
import {createBookingAndOrder} from 'backend/booking';

export async function onBookNowClick() {
  const details = { /* collect from page inputs */ };
  const { bookingId, order } = await createBookingAndOrder(details);
  const options = {
    key: "RAZORPAY_KEY_ID", // replace with public key (or fetch from backend)
    amount: order.amount,
    currency: order.currency,
    name: "AK Holidays",
    description: details.packageName,
    order_id: order.id,
    handler: async function (response) {
      // call backend to verify and update booking status
      await wixFetch.post('/_functions/verifyPayment', {body: { paymentId: response.razorpay_payment_id, orderId: response.razorpay_order_id }});
      // show confirmation to user
    },
    prefill: { name: details.name, email: details.email, contact: details.phone },
  };
  const rzp = new Razorpay(options);
  rzp.open();
}
```

### D) Razorpay webhook verification example (Node.js / Express style)
```javascript
// webhook example (for external server)
const crypto = require('crypto');
app.post('/razorpay-webhook', express.json(), (req, res) => {
  const secret = process.env.RZP_WEBHOOK_SECRET;
  const shasum = crypto.createHmac('sha256', secret).update(JSON.stringify(req.body)).digest('hex');
  if (shasum === req.headers['x-razorpay-signature']) {
    // handle event (payment.captured, payment.failed, refund.processed)
    res.status(200).end();
  } else {
    res.status(400).end();
  }
});
```

## 4) Suggested Velo Collections (Wix DB)
- Packages (title, slug, state, duration, price, images, templateSteps JSON)
- Bookings (name, email, phone, packageId, travellers, amount, status, createdAt, razorpayOrderId, razorpayPaymentId)
- Customers (name, email, phone, bookings[])
- Roadmaps (owner, packageId, items JSON, public, shareSlug)

## 5) Security & Secrets
- Store Razorpay keys and webhook secret in Wix Secrets Manager (`wix-secrets-backend`). Never expose keys on client-side.
- Use server-side (backend .jsw) to call Razorpay APIs and to verify payment signatures.

## 6) Next steps (recommended)
1. Add screenshots to /assets and real content files in /content.
2. Add the Velo backend code to Wix and configure secrets.
3. Create a dynamic package page for each package (SEO-friendly slug).
4. Add automated emails using Wix Automations or a transactional email provider.
5. Implement webhook endpoint for payment status updates and refund automation.

---
Generated by assistant after scanning https://akholidaysofficial.in (official domain)
